package com.geektrust.backend.services;

import com.geektrust.backend.dtos.RenewalAmountDto;
import com.geektrust.backend.dtos.RenewalReminderDto;
import com.geektrust.backend.exceptions.SubscriptionNotFoundException;

import java.util.List;

public interface IRenewalService {
    List<RenewalReminderDto> calculateListOfRenewalDateOfSubscriptions() throws SubscriptionNotFoundException;
    RenewalAmountDto calculateRenewalAmount();
}