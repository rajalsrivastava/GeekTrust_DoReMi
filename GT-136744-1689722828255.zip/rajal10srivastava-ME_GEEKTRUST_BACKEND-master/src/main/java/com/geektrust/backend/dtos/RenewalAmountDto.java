package com.geektrust.backend.dtos;

public class RenewalAmountDto {
    private final Integer renewalAmount;

    public RenewalAmountDto(Integer renewalAmount) {
        this.renewalAmount = renewalAmount;
    }

    @Override
    public String toString() {
        return "RENEWAL_AMOUNT" +
                " " + renewalAmount;
    }
}